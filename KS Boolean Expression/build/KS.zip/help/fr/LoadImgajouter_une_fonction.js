function LoadImg(){var adbt0=document.getElementById('adbt0');adbt0.onmouseout=adbt0out;adbt0.onmouseover=adbt0over;
var adbt1=document.getElementById('adbt1');adbt1.onmouseout=adbt1out;adbt1.onmouseover=adbt1over;
var adbt2=document.getElementById('adbt2');adbt2.onmouseout=adbt2out;adbt2.onmouseover=adbt2over;
var adbt3=document.getElementById('adbt3');adbt3.onmouseout=adbt3out;adbt3.onmouseover=adbt3over;

MM_preloadImages('dbt2.png');MM_preloadImages('dbt6.png');MM_preloadImages('dbt8.png');MM_preloadImages('dbt4.png');}
function adbt0out(){MM_swapImgRestore()}
function adbt0over(){MM_swapImage('dbt0','dbt0','dbt2.png')}
function adbt1out(){MM_swapImgRestore()}
function adbt1over(){MM_swapImage('dbt1','dbt1','dbt6.png')}
function adbt2out(){MM_swapImgRestore()}
function adbt2over(){MM_swapImage('dbt2','dbt2','dbt8.png')}
function adbt3out(){MM_swapImgRestore()}
function adbt3over(){MM_swapImage('dbt3','dbt3','dbt4.png')}
