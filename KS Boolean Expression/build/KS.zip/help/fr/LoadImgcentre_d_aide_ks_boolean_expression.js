function LoadImg(){var adbt0=document.getElementById('adbt0');adbt0.onmouseout=adbt0out;adbt0.onmouseover=adbt0over;
var adbt1=document.getElementById('adbt1');adbt1.onmouseout=adbt1out;adbt1.onmouseover=adbt1over;

MM_preloadImages('dbt2.png');MM_preloadImages('dbt4.png');}
function adbt0out(){MM_swapImgRestore()}
function adbt0over(){MM_swapImage('dbt0','dbt0','dbt2.png')}
function adbt1out(){MM_swapImgRestore()}
function adbt1over(){MM_swapImage('dbt1','dbt1','dbt4.png')}
