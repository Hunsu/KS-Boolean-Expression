            _________________________________________________
           |                                                 |
           |           KS Boolean Expression � 1.0           |
           |               Copyright � 2012.                 |
           |         http://www.sourceforge.com/p/ksbe       |
           |            ks.contibutors@gmail.com             |
           |_________________________________________________|


Welcome to the KS Boolean Expression README file. 
This file my contain important information relating to the use of this program. Please read it attentively.
  
----------------------------
         CONTENTS
----------------------------
0 ABOUT KS Boolean Expression
1 SYSTEM REQUIREMENTS
2 INSTALLATION
3 CONTACTS
4 UPDATES
5 LICENSE
----------------------------
   


0 ABOUT KS Boolean Expression:
*****************************
KS Boolean Expression is a free software used to minimize boolean functions by a graphic method of Karnaugh maps.

Useful for the developers of small digital devices, and as 
for those who are familiar with Boolean algebra, and for the electrical engineering students.


1 SYSTEM REQUIREMENTS:
*********************
This software is compatible with all the versions of Windows Mac OS and Linux
Although, it requires the presence of JVM 1.6 (or higher)on your machine and 6 MB of free disk space.

2 INSTALLATION:
**************
To install this program on your computer you have just to run the SetUp.exe file and then follow the instructions.

3 CONTACTS:
**********
If you have any problems, questions or suggestions please email to ks.contibutors@gmail.com

4 UPDATES:
*********
You may find the lastest updates of KS Boolean Expression at http://www.sourceforge.com/p/ksbe

5 LICENSE:
*********
KS Boolean Expression is a free software distributed under the GNU General Public License. 
For more information about license please read the license.txt file.



Thank you!


Have fun with KS Boolean Expression!
The authors
